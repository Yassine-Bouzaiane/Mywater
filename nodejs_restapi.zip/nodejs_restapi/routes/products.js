// will contain all of my user related routes
const express = require('express')
const mysql = require('mysql')
const products = express.Router()


const pool = mysql.createPool({
    connectionLimit: 10,
    host: '127.0.0.1',
    user: 'root',
    database: 'mywater'
})

function getConnection() {
    return pool
}


// create produit
products.post('/produit_create', (req, res) => {
  console.log("Trying to create a new produit...")
  console.log("How do we get the form data???")
 const imageProd = req.body.create_imageProd
 const reference = req.body.create_reference
 const nom = req.body.create_nom
 const prix = req.body.create_prix
  const description = req.body.create_description
  const categorie = req.body.create_categorie
  const quantite = req.body.create_quantite
  const queryString = "INSERT INTO produit (imageProd, reference, nom, prix , description , categorie , quantite) VALUES (?,?,?,?, ?, ?,?)"
  getConnection().query(queryString, [imageProd, reference , nom, prix , description , categorie , quantite], (err, results, fields) => {
    if (err) {
      console.log("Failed to insert new produit: " + err)
      res.sendStatus(500)
      return
    }

    console.log("Inserted a new produit with id: ", results.insertId);
    res.end()
  })
})

//get all prod
products.get('/show', (req, res) => {
    const connection = getConnection()
    const queryString = "SELECT * FROM produit"
    connection.query(queryString, (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for produits: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched produits successfully")
  
        const produits = rows.map((row) => {
          return {idProd: row.idProd, reference: row.reference, nom: row.nom, description: row.description, imageProd: row.imageProd, categorie: row.categorie, quantite: row.quantite }
        })
  
        res.json(produits)
    })
  
  })
  
  
  
  
  //get all prod by eau
  products.get('/show/eau', (req, res) => {
    const connection = getConnection()
    const queryString = "SELECT * FROM produit where categorie ='eau'"
    connection.query(queryString, (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for produits: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched produits successfully")
  
        const produits = rows.map((row) => {
        return {idProd: row.idProd, reference: row.reference, nom: row.nom, description: row.description, prix: row.prix, imageProd: row.imageProd, categorie: row.categorie, quantite: row.quantite }
        })
  
        res.json(produits)
    })
  
  })
  
  
  //get all prod by piscine
  products.get('/show/piscine', (req, res) => {
    const connection = getConnection()
    const queryString = "SELECT * FROM produit where categorie ='piscine'"
    connection.query(queryString, (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for produits: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched produits successfully")
  
        const produits = rows.map((row) => {
          return {idProd: row.idProd, reference: row.reference, nom: row.nom, description: row.description, prix: row.prix, imageProd: row.imageProd, categorie: row.categorie, quantite: row.quantite }
        })
  
        res.json(produits)
    })
  
  })

    
  //get all prod by Elect
  products.get('/show/elect', (req, res) => {
    const connection = getConnection()
    const queryString = "SELECT * FROM produit where categorie ='electricite'"
    connection.query(queryString, (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for produits: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched produits successfully")
  
        const produits = rows.map((row) => {
          return {idProd: row.idProd, reference: row.reference, nom: row.nom, description: row.description, prix: row.prix, imageProd: row.imageProd, categorie: row.categorie, quantite: row.quantite }
        })
  
        res.json(produits)
    })
  
  })

//get prod by id
products.get('/show/:idProd', (req, res) => {
    const idProd = req.params.idProd
    const connection = getConnection()
    const queryString = "SELECT * FROM produit where idProd = ?"
    connection.query(queryString, [idProd], (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for produits: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched produits successfully")
  
        const produits = rows.map((row) => {
        return {idProd: row.idProd, reference: row.reference, nom: row.nom, description: row.description, prix: row.prix, imageProd: row.imageProd, categorie: row.categorie, quantite: row.quantite }
        })
  
        res.json(produits)
    })
  
  })
  

//delete produit
products.delete('/delete/:idProd',(req,res) => {
  const sql = "DELETE FROM produit WHERE idProd = ?";
  const idProd = req.params.idProd;
  pool.query(sql, idProd, (err, results, fields) => {
    if (err) {
      console.log("Failed to insert new produit: " + err)
      res.sendStatus(500)
      return
    }
  
    console.log("deleted produit with id: ", results.insertId);
    res.end()
  })
  })

  
// update produit
products.post('/update', (req, res) => {
  console.log("Trying to update the produit...")
  console.log("How do we get the form data???")
 const imageProd = req.body.create_imageProd
 const reference = req.body.create_reference
 const nom = req.body.create_nom
 const prix = req.body.create_prix
  const description = req.body.create_description
  const categorie = req.body.create_categorie
  const quantite = req.body.create_quantite
  
 // const Password = req.body.create_password

  const queryString = "UPDATE produit SET imageProd = ?, reference = ?, nom = ?, prix = ? , description = ? , categorie = ? , quantite = ? WHERE idProd = ?"
  getConnection().query(queryString, [imageProd, reference , nom, prix , description , categorie , quantite , idProd], (err, results, fields) => {
    if (err) {
      console.log("Failed to insert new produit: " + err)
      res.sendStatus(500)
      return
    }

    console.log("Inserted a new produit with id: ", results.insertId);
    res.end()
  })
})
module.exports = products