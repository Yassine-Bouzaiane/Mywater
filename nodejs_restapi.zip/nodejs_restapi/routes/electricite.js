// will contain all of my user related routes
const express = require('express')
const mysql = require('mysql')
const electricite = express.Router()


const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'localhost',
    user: 'root',
    database: 'mywater'
})

function getConnection() {
    return pool
}




//get list electricite
electricite.get('/show', (req, res) => {
    const connection = getConnection()
    const queryString = "SELECT * FROM electricite"
    connection.query(queryString, (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for electricite: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched produits successfully")
  
        const produits = rows.map((row) => {
          return {idElect: row.id, titre: row.titre, description: row.description, imageElect: row.imageElect  }
        })
  
        res.json(produits)
    })
  
  })
  
  //delete from elect list
  
  electricite.delete("/delete/:id", (req, res) => {
    pool.query("DELETE FROM electricite where id = ?", [req.params.id], (err, rows, fields) => {
        res.status(204)
        res.end()
    })
  })

  

  
module.exports = electricite