// will contain all of my user related routes
const express = require('express')
const mysql = require('mysql')
const carte = express.Router()


const pool = mysql.createPool({
    connectionLimit: 10,
    host: '127.0.0.1',
    user: 'root',
    database: 'mywater'
})

function getConnection() {
    return pool
}


//get carte by id
carte.get('/show', (req, res) => {
    const id_carte = req.params.id_carte
    const connection = getConnection()
    const queryString = "SELECT * FROM carte c,produit p,user u WHERE c.id_user = u.id and c.id_prod = p.idProd"
    connection.query(queryString, [id_carte], (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for cartes: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched cartes successfully")
  
        const cartes = rows.map((row) => {
        return {id_carte: row.id_carte, id_user: row.id_user,
             imageProd: row.imageProd,
             reference: row.reference, nom: row.nom, prix: row.prix, decription: row.decription,
              categorie: row.categorie, quantite: row.quantite,
               id: row.id, name: row.name, Password: row.Password, email: row.email,
                address: row.address, imageUser: row.imageUser, typeUser: row.typeUser}
        })
  
        res.json(cartes)
    })
  
  })



// create carte
carte.post('/create', (req, res) => {
    console.log("Trying to create a new carte...")
    console.log("How do we get the form data???")
  
    
   // const id_carte = req.body.create_id_carte
    const id_user = req.body.create_id_user
    const id_prod = req.body.create_id_prod
    const quantiteCart = req.body.create_quantite
   // const Password = req.body.create_password
  
    const queryString = "INSERT INTO carte (id_user, id_prod, quantiteCart) VALUES (?, ?, ?)"
    getConnection().query(queryString, [id_user, id_prod, quantiteCart], (err, results, fields) => {
      if (err) {
        console.log("Failed to insert new carte: " + err)
        res.sendStatus(500)
        return
      }
  
      console.log("Inserted a new carte with id: ", results.insertId);
      res.end()
    })
  })


// get user's carte
carte.get('/show/:id_user', (req, res) => {
    const id_user = req.params.id_user
    const connection = getConnection()
    const queryString = "SELECT * FROM carte c,produit p,user u WHERE c.id_user = ? and c.id_user = u.id and c.id_prod = p.idProd "
    connection.query(queryString, [id_user], (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for cartes: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched cartes successfully")
  
        const cartes = rows.map((row) => {
          return {id_user: row.id_user, id_prod: row.id_prod, quantiteCart: row.quantiteCart,
            imageProd: row.imageProd,
            reference: row.reference, nom: row.nom, prix: row.prix, description: row.description,
             categorie: row.categorie, quantite: row.quantite,
              id: row.id, name: row.name, Password: row.Password, email: row.email,
               address: row.address, imageUser: row.imageUser, typeUser: row.typeUser}
       })
 
       
        res.json(cartes)
    })
  
  })
  

/*
//get carte by id
carte.get('/carte/:id_carte', (req, res) => {
    const id_carte = req.params.id_carte
    const connection = getConnection()
    const queryString = "SELECT * FROM carte where id_carte = ?"
    connection.query(queryString, [id_carte], (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for cartes: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched cartes successfully")
  
        const cartes = rows.map((row) => {
        return {id_carte: row.id_carte, id_user: row.id_user}
        })
  
        res.json(cartes)
    })
  
  })
  */
// update carte
carte.post('/carte_etat_update', (req, res) => {

  console.log("name: " + req.body.create_name)
  
  const name = req.body.create_name
  const email = req.body.create_email
  const Password = req.body.create_Password
  const imageUser = req.body.create_imageUser
  const typeUser = req.body.create_typeUser
  const address = req.body.create_address
 // const Password = req.body.create_password

  const queryString = "UPDATE user name = ?, email = ?, Password = ?, imageUser = ?, address = ? typeUser = ? Where id = ?  "
  getConnection().query(queryString, [name, email, Password, imageUser, address, typeUser], (err, results, fields) => {
    if (err) {
      console.log("Failed to insert new user: " + err)
      res.sendStatus(500)
      return
    }

    console.log("Inserted a new user with id: ", results.insertId);
    res.end()
  })
})




  module.exports = carte