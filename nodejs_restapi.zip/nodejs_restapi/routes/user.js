
// will contain all of my user related routes
const express = require('express')
const mysql = require('mysql')
const router = express.Router()


const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'localhost',
    user: 'root',
    database: 'mywater'
})

function getConnection() {
    return pool
}





// create user
router.post('/user_create', (req, res) => {
    console.log("Trying to create a new user...")
    console.log("How do we get the form data???")
  
    console.log("name: " + req.body.create_name)
    
    const name = req.body.create_name
    const email = req.body.create_email
    const Password = req.body.create_Password
    const imageUser = req.body.create_imageUser
    const typeUser = req.body.create_typeUser
    const address = req.body.create_address
   // const Password = req.body.create_password
  
    const queryString = "INSERT INTO user (name, email, Password, imageUser, address, typeUser) VALUES (?, ?, ?, ?, ?, ?)"
    getConnection().query(queryString, [name, email, Password, imageUser, address, typeUser], (err, results, fields) => {
      if (err) {
        console.log("Failed to insert new user: " + err)
        res.sendStatus(500)
        return
      }
  
      console.log("Inserted a new user with id: ", results.insertId);
      res.end()
    })
  })
  
// update user
router.post('/user_update', (req, res) => {
  console.log("Trying to create a new user...")
  console.log("How do we get the form data???")

  console.log("name: " + req.body.create_name)
  
  const id_user = req.body.create_id_user
  const name = req.body.create_name
  const email = req.body.create_email
  const Password = req.body.create_Password
  const imageUser = req.body.create_imageUser
  const typeUser = req.body.create_typeUser
  const address = req.body.create_address
 // const Password = req.body.create_password

  const queryString = "UPDATE user set name = ?, email = ?, Password = ?, imageUser = ?, address = ?, typeUser = ? Where id = ?  "
  getConnection().query(queryString, [name, email, Password, imageUser, address, typeUser, id_user], (err, results, fields) => {
    if (err) {
      console.log("Failed to insert new user: " + err)
      res.sendStatus(500)
      return
    }

    console.log("Inserted a new user with id: ", results.insertId);
    res.end()
  })
})


  //get user by email
router.get('/userss/:email', (req, res) => {
  const email = req.params.email
  const connection = getConnection()
  const queryString = "SELECT * FROM user where email = ?"
  connection.query(queryString, [email], (err, rows, fields) => {
    //  console.log("fetched SUCCESS")
     // res.json(rows)

     if (err) {
      console.log("Failed to query for users: " + err)
      res.sendStatus(500)
      return
      // throw err
      }

      console.log("I think we fetched users successfully")

      const users = rows.map((row) => {
      return {name: row.name, Password: row.Password, email: row.email, imageUser: row.imageUser}
      })

      res.json(rows)
  })

})

  //get user by id
  router.get('/userss/id/:id', (req, res) => {
    const id = req.params.id
    const connection = getConnection()
    const queryString = "SELECT * FROM user where id = ?"
    connection.query(queryString, [id], (err, rows, fields) => {
      //  console.log("fetched SUCCESS")
       // res.json(rows)
  
       if (err) {
        console.log("Failed to query for users: " + err)
        res.sendStatus(500)
        return
        // throw err
        }
  
        console.log("I think we fetched users successfully")
  
        const users = rows.map((row) => {
        return {rows}
        })
  
        res.json(rows)
    })
  
  })
  

/*
//get all users
router.get('/userss', (req, res) => {
  const connection = getConnection()
  const queryString = "SELECT * FROM user"
  connection.query(queryString, (err, rows, fields) => {
      console.log("fetched SUCCESS")
      res.json(rows)
  })

})
*/

//GET all users
router.get("/userss", (req, res) => {
  pool.query("SELECT * FROM user", (err, user_rows, fields) => {
      res.status(200)
      res.json(user_rows)
  })
})



/*

// get user's carte
router.get('/carte/user/:id_user', (req, res) => {
  const id_user = req.params.id_user
  const connection = getConnection()
  const queryString = "SELECT * FROM carte where id_user = ?"
  connection.query(queryString, [id_user], (err, rows, fields) => {
    //  console.log("fetched SUCCESS")
     // res.json(rows)

     if (err) {
      console.log("Failed to query for cartes: " + err)
      res.sendStatus(500)
      return
      // throw err
      }

      console.log("I think we fetched cartes successfully")

      const cartes = rows.map((row) => {
      return {id_carte: row.id_carte, id_user: row.id_user}
      })

      res.json(cartes)
  })

})
*/


/////////////// WAREF ///////////////

/*


router.post('/user_create', (req, res) => {
  console.log("Trying to create a new user...")
  console.log("How do we get the form data???")

  console.log("name: " + req.body.create_name)
  
  const name = req.body.create_name
  const email = req.body.create_email
  const Password = req.body.create_Password
  const imageUser = req.body.create_imageUser
  const typeUser = req.body.create_typeUser
  const address = req.body.create_address
  const phone = req.body.create_phone
  

  const queryString = "INSERT INTO user (name, email, Password, imageUser, address, typeUser, phone) VALUES (?, ?, ?, ?, ?, ?, ?)"
  getConnection().query(queryString, [name, email, Password, imageUser, address, typeUser, phone], (err, results, fields) => {
    if (err) {
      console.log("Failed to insert new user: " + err)
      res.sendStatus(500)
      return
    }

    console.log("Inserted a new user with id: ", results.insertId);
    res.send(router)
    res.end()
  })
})

//get all users
router.get('/userss', (req, res) => {
  const connection = getConnection()
  const queryString = "SELECT * FROM user"
  connection.query(queryString, (err, rows, fields) => {
      console.log("fetched SUCCESS")
      res.json(rows)
  })

})

//get user by email
router.get('/userss/:email', (req, res) => {
  const email = req.params.email
  const connection = getConnection()
  const queryString = "SELECT * FROM user where email = ?"
  connection.query(queryString, [email], (err, rows, fields) => {
    //  console.log("fetched SUCCESS")
     // res.json(rows)

     if (err) {
      console.log("Failed to query for users: " + err)
      res.sendStatus(500)
      return
      // throw err
      }

      console.log("I think we fetched users successfully")

      const users = rows.map((row) => {
      return {id: row.id, name: row.name, email: row.email, Password: row.Password , address: row.address, imageUser: row.imageUser, phone: row.phone, typeUser: row.typeUser}
      })

      res.json(users)
  })

})

// update user
router.post('/user_update', (req, res) => {
  console.log("Trying to update the produit...")
  console.log("How do we get the form data???")
  const id_user = req.body.create_id_user
  const name = req.body.create_name
  const email = req.body.create_email
  const Password = req.body.create_Password
  const imageUser = req.body.create_imageUser
  const typeUser = req.body.create_typeUser
  const address = req.body.create_address
  const phone = req.body.create_phone
  
  const queryString = "UPDATE user SET name = ?, email = ?, Password = ?, imageUser = ? , typeUser = ? , address = ? , phone = ? WHERE id = ?"
  getConnection().query(queryString, [name, email , Password, imageUser , typeUser , address, phone, id_user], (err, results, fields) => {
    if (err) {
      console.log("Failed to update user: " + err)
      res.sendStatus(500)
      return
    }
    console.log("Updated a new user with id: ", results.insertId);

    console.log("updated a User ");
    res.end()
  })
})
*/
module.exports = router
